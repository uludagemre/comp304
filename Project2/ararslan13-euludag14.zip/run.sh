g++ -pthread -o project2_output project2.cpp
./project2_output -s 60 -p 0.4 -t 10
