Project 2 Readme

In this project we are running the police-intersection simulation with the run.sh file.

In order to set the duration of the program you must change the first argument ie. argument after -s

In order to set a car’s arrival (note that cars arrive from north with probability of 1-p) probability p, you must change the second argument i.e argument after -p

In order to set the time that the program writes snapshots to the log, you must change the third argument i.e argument after -t

To run the project cd into the project folder and after setting the arguments run the file with ./run.sh command. 
Wait for three different log outputs. These files are called :
police.log, snapshot.log, car.log
